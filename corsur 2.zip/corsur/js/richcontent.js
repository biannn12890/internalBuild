export function parseRichContent(rawText) {
  var segments = [];
  var fenceRegex = /```(table|math|currency|code)\n([\s\S]*?)```/g;
  var lastIndex = 0;
  var match;

  while ((match = fenceRegex.exec(rawText)) !== null) {
    if (match.index > lastIndex) {
      var before = rawText.slice(lastIndex, match.index).trim();
      if (before) segments.push({ type: "text", content: before });
    }
    segments.push({ type: match[1], content: match[2].trim() });
    lastIndex = match.index + match[0].length;
  }

  var rest = rawText.slice(lastIndex).trim();
  if (rest) segments.push({ type: "text", content: rest });

  if (segments.length === 0) segments.push({ type: "text", content: rawText });

  return detectMarkdownTables(segments);
}

function detectMarkdownTables(segments) {
  var output = [];
  segments.forEach(function (seg) {
    if (seg.type !== "text") {
      output.push(seg);
      return;
    }
    var lines = seg.content.split("\n");
    var buffer = [];
    var tableBuffer = [];
    var inTable = false;

    function flushText() {
      if (buffer.length) {
        output.push({ type: "text", content: buffer.join("\n").trim() });
        buffer = [];
      }
    }
    function flushTable() {
      if (tableBuffer.length >= 2) {
        output.push({ type: "table", content: tableBuffer.join("\n") });
      } else {
        buffer = buffer.concat(tableBuffer);
      }
      tableBuffer = [];
      inTable = false;
    }

    lines.forEach(function (line) {
      var looksLikeRow = /^\s*\|.*\|\s*$/.test(line);
      if (looksLikeRow) {
        inTable = true;
        tableBuffer.push(line);
      } else {
        if (inTable) flushTable();
        buffer.push(line);
      }
    });
    if (inTable) flushTable();
    flushText();
  });
  return output.filter(function (s) { return s.content.length > 0; });
}

export function parseMarkdownTable(raw) {
  var lines = raw.split("\n").map(function (l) { return l.trim(); }).filter(Boolean);
  var rows = lines
    .filter(function (l) { return !/^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(l); })
    .map(function (line) {
      var cells = line.replace(/^\|/, "").replace(/\|$/, "").split("|");
      return cells.map(function (c) { return c.trim(); });
    });
  return rows;
}

export function renderInlineMarkdown(text) {
  var escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  escaped = escaped.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
  escaped = escaped.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  escaped = escaped.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  escaped = escaped.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  return escaped;
}

export function renderTextBlock(content) {
  var paragraphs = content.split(/\n{2,}/);
  return paragraphs.map(function (p) {
    var lines = p.split("\n").map(renderInlineMarkdown);
    return "<p>" + lines.join("<br>") + "</p>";
  }).join("");
}
