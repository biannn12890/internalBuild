import { auth, db, googleProvider } from "./firebase-config.js";
import {
  signInWithPopup,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";
import {
  doc,
  setDoc,
  getDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

const AVATAR_PALETTE = [
  "#5B6FFF", "#FF6FA0", "#2FBF8F", "#FF8A3D",
  "#7B61FF", "#19B7D9", "#FF5A7A", "#3D8BFF"
];

function colorForName(name) {
  var sum = 0;
  for (var i = 0; i < name.length; i++) sum += name.charCodeAt(i);
  return AVATAR_PALETTE[sum % AVATAR_PALETTE.length];
}

function initialsForName(name) {
  var parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

async function ensureUserDoc(user, displayNameOverride) {
  var ref = doc(db, "users", user.uid);
  var snap = await getDoc(ref);
  var name = displayNameOverride || user.displayName || user.email.split("@")[0];

  if (!snap.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      name: name,
      nameLower: name.toLowerCase(),
      email: user.email,
      photoURL: user.photoURL || null,
      avatarColor: colorForName(name),
      avatarInitials: initialsForName(name),
      status: "online",
      lastSeen: serverTimestamp(),
      createdAt: serverTimestamp()
    });
  } else {
    await setDoc(ref, { status: "online", lastSeen: serverTimestamp() }, { merge: true });
  }
  return ref;
}

export function watchAuthState(onSignedIn, onSignedOut) {
  return onAuthStateChanged(auth, function (user) {
    if (user) {
      ensureUserDoc(user).then(function () {
        onSignedIn(user);
      });
    } else {
      onSignedOut();
    }
  });
}

export async function loginWithGoogle() {
  var result = await signInWithPopup(auth, googleProvider);
  return result.user;
}

export async function registerWithEmail(name, email, password) {
  var cred = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(cred.user, { displayName: name });
  await ensureUserDoc(cred.user, name);
  return cred.user;
}

export async function loginWithEmail(email, password) {
  var cred = await signInWithEmailAndPassword(auth, email, password);
  return cred.user;
}

export async function logout() {
  var uid = auth.currentUser ? auth.currentUser.uid : null;
  if (uid) {
    try {
      await setDoc(doc(db, "users", uid), { status: "offline", lastSeen: serverTimestamp() }, { merge: true });
    } catch (e) {
      console.error("Gagal update status offline:", e);
    }
  }
  await signOut(auth);
}

export function mapAuthError(code) {
  var map = {
    "auth/email-already-in-use": "Email ini udah dipake. Coba login aja.",
    "auth/invalid-email": "Format emailnya salah.",
    "auth/weak-password": "Password minimal 6 karakter.",
    "auth/user-not-found": "Akun gak ketemu. Cek lagi emailnya.",
    "auth/wrong-password": "Password salah.",
    "auth/invalid-credential": "Email atau password salah.",
    "auth/popup-closed-by-user": "Popup Google ditutup duluan.",
    "auth/too-many-requests": "Kebanyakan nyoba. Tunggu bentar."
  };
  return map[code] || "Ada yang error, coba lagi.";
}
