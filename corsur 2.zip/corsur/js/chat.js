import { db } from "./firebase-config.js";
import {
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  limit
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

var unsubscribeMessages = null;
var unsubscribeChatList = null;

export function chatIdFor(uidA, uidB) {
  return [uidA, uidB].sort().join("_");
}

export async function openOrCreateChat(myProfile, otherProfile) {
  var id = chatIdFor(myProfile.uid, otherProfile.uid);
  var ref = doc(db, "chats", id);
  var snap = await getDoc(ref);
  if (!snap.exists()) {
    var participantsInfo = {};
    participantsInfo[myProfile.uid] = {
      name: myProfile.name,
      avatarColor: myProfile.avatarColor,
      avatarInitials: myProfile.avatarInitials,
      photoURL: myProfile.photoURL || null
    };
    participantsInfo[otherProfile.uid] = {
      name: otherProfile.name,
      avatarColor: otherProfile.avatarColor,
      avatarInitials: otherProfile.avatarInitials,
      photoURL: otherProfile.photoURL || null
    };
    await setDoc(ref, {
      participants: [myProfile.uid, otherProfile.uid],
      participantsInfo: participantsInfo,
      lastMessage: "",
      lastMessageTime: serverTimestamp(),
      lastSenderId: ""
    });
  }
  return id;
}

export function watchChatList(myUid, onChats) {
  if (unsubscribeChatList) unsubscribeChatList();
  var q = query(
    collection(db, "chats"),
    orderBy("lastMessageTime", "desc"),
    limit(100)
  );
  unsubscribeChatList = onSnapshot(q, function (snap) {
    var chats = [];
    snap.forEach(function (docSnap) {
      var data = docSnap.data();
      if (data.participants && data.participants.indexOf(myUid) !== -1) {
        chats.push(Object.assign({ id: docSnap.id }, data));
      }
    });
    onChats(chats);
  });
  return unsubscribeChatList;
}

export function watchMessages(chatId, onMessages) {
  if (unsubscribeMessages) unsubscribeMessages();
  var q = query(
    collection(db, "chats", chatId, "messages"),
    orderBy("createdAt", "asc"),
    limit(500)
  );
  unsubscribeMessages = onSnapshot(q, function (snap) {
    var messages = [];
    snap.forEach(function (docSnap) {
      messages.push(Object.assign({ id: docSnap.id }, docSnap.data()));
    });
    onMessages(messages);
  });
  return unsubscribeMessages;
}

export function stopWatchingMessages() {
  if (unsubscribeMessages) {
    unsubscribeMessages();
    unsubscribeMessages = null;
  }
}

export async function sendMessage(chatId, senderId, text, imageBase64) {
  var trimmed = (text || "").trim();
  if (!trimmed && !imageBase64) return;

  await addDoc(collection(db, "chats", chatId, "messages"), {
    senderId: senderId,
    text: trimmed,
    image: imageBase64 || null,
    createdAt: serverTimestamp()
  });

  var preview = imageBase64 ? "\uD83D\uDDBC\uFE0F Gambar" : trimmed;
  await setDoc(
    doc(db, "chats", chatId),
    {
      lastMessage: preview,
      lastMessageTime: serverTimestamp(),
      lastSenderId: senderId
    },
    { merge: true }
  );
}

export function formatTimestamp(ts) {
  if (!ts || !ts.toDate) return "";
  var d = ts.toDate();
  var now = new Date();
  var sameDay = d.toDateString() === now.toDateString();
  if (sameDay) {
    return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
  }
  var yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return "Kemarin";
  return d.toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "2-digit" });
}
