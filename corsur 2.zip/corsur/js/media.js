export function compressImageToBase64(file, maxDimension, quality) {
  maxDimension = maxDimension || 1280;
  quality = quality || 0.72;

  return new Promise(function (resolve, reject) {
    if (!file.type.startsWith("image/")) {
      reject(new Error("File bukan gambar."));
      return;
    }
    var reader = new FileReader();
    reader.onerror = function () { reject(new Error("Gagal baca file.")); };
    reader.onload = function () {
      var img = new Image();
      img.onerror = function () { reject(new Error("Gagal decode gambar.")); };
      img.onload = function () {
        var w = img.width;
        var h = img.height;
        if (w > maxDimension || h > maxDimension) {
          if (w > h) {
            h = Math.round((h * maxDimension) / w);
            w = maxDimension;
          } else {
            w = Math.round((w * maxDimension) / h);
            h = maxDimension;
          }
        }
        var canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        var ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

var lazyObserver = null;

function getLazyObserver() {
  if (lazyObserver) return lazyObserver;
  lazyObserver = new IntersectionObserver(
    function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        var img = entry.target;
        var src = img.getAttribute("data-src");
        if (src) {
          img.src = src;
          img.removeAttribute("data-src");
          img.classList.add("media-loaded");
        }
        lazyObserver.unobserve(img);
      });
    },
    { rootMargin: "200px 0px" }
  );
  return lazyObserver;
}

export function lazyMountImage(imgEl) {
  getLazyObserver().observe(imgEl);
}

export function lazyMountAllWithin(containerEl) {
  var imgs = containerEl.querySelectorAll("img[data-src]");
  imgs.forEach(function (img) { lazyMountImage(img); });
}
