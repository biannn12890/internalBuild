import { db, VUNOS_WORKER_URL } from "./firebase-config.js";
import {
  collection,
  doc,
  addDoc,
  deleteDoc,
  getDocs,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  limit,
  updateDoc
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";
import { parseRichContent, parseMarkdownTable, renderTextBlock } from "./richcontent.js";

var VUNOS_SYSTEM_PROMPT = [
  "Lu adalah Vunos, asisten AI di dalam app Corsur.",
  "Jawab natural pake bahasa yang dipake user.",
  "Kalo user minta atau konteksnya pas buat tabel, bungkus tabel itu dalam blok ```table",
  "berisi markdown table valid (header | header lalu baris pemisah lalu data).",
  "Kalo ada perhitungan matematika yang pantas ditulis sebagai ekspresi, bungkus dalam blok ```math",
  "berisi LaTeX murni tanpa $ atau \\( \\).",
  "Kalo user minta konversi mata uang, bungkus hasilnya dalam blok ```currency",
  "berisi JSON persis: {\"from\":\"KODE\",\"to\":\"KODE\",\"amount\":angka,\"result\":angka,\"rate\":angka}.",
  "Selain bagian-bagian khusus itu, tulis sebagai teks biasa mengalir, jangan pakai bubble atau markdown heading berlebihan."
].join(" ");

var pendingImages = [];
var unsubscribeThreadList = null;
var unsubscribeThreadMessages = null;

export function addPendingImage(base64) { pendingImages.push(base64); }
export function removePendingImage(index) { pendingImages.splice(index, 1); }
export function clearPendingImages() { pendingImages = []; }
export function getPendingImages() { return pendingImages.slice(); }

function threadsCollection(uid) {
  return collection(db, "users", uid, "vunosThreads");
}
function messagesCollection(uid, threadId) {
  return collection(db, "users", uid, "vunosThreads", threadId, "messages");
}

export async function createThread(uid) {
  var ref = await addDoc(threadsCollection(uid), {
    title: "Percakapan baru",
    hasVision: false,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return ref.id;
}

export function watchThreadList(uid, onThreads) {
  if (unsubscribeThreadList) unsubscribeThreadList();
  var q = query(threadsCollection(uid), orderBy("updatedAt", "desc"), limit(100));
  unsubscribeThreadList = onSnapshot(q, function (snap) {
    var threads = [];
    snap.forEach(function (docSnap) {
      threads.push(Object.assign({ id: docSnap.id }, docSnap.data()));
    });
    onThreads(threads);
  });
  return unsubscribeThreadList;
}

export function stopWatchingThreadList() {
  if (unsubscribeThreadList) { unsubscribeThreadList(); unsubscribeThreadList = null; }
}

export function watchThreadMessages(uid, threadId, onMessages) {
  if (unsubscribeThreadMessages) unsubscribeThreadMessages();
  var q = query(messagesCollection(uid, threadId), orderBy("createdAt", "asc"), limit(300));
  unsubscribeThreadMessages = onSnapshot(q, function (snap) {
    var messages = [];
    snap.forEach(function (docSnap) {
      messages.push(Object.assign({ id: docSnap.id }, docSnap.data()));
    });
    onMessages(messages);
  });
  return unsubscribeThreadMessages;
}

export function stopWatchingThreadMessages() {
  if (unsubscribeThreadMessages) { unsubscribeThreadMessages(); unsubscribeThreadMessages = null; }
}

export async function deleteThread(uid, threadId) {
  var msnap = await getDocs(messagesCollection(uid, threadId));
  var jobs = [];
  msnap.forEach(function (d) { jobs.push(deleteDoc(d.ref)); });
  await Promise.all(jobs);
  await deleteDoc(doc(db, "users", uid, "vunosThreads", threadId));
}

async function saveMessage(uid, threadId, role, text, images) {
  var payload = { role: role, text: text || "", createdAt: serverTimestamp() };
  if (images && images.length) payload.images = images;
  await addDoc(messagesCollection(uid, threadId), payload);
}

function deriveTitle(text) {
  var clean = (text || "").trim().replace(/\s+/g, " ");
  if (!clean) return "Percakapan baru";
  return clean.length > 38 ? clean.slice(0, 38) + "\u2026" : clean;
}

async function touchThread(uid, threadId, newTitle, markVision) {
  var updates = { updatedAt: serverTimestamp() };
  if (newTitle) updates.title = newTitle;
  if (markVision) updates.hasVision = true;
  await updateDoc(doc(db, "users", uid, "vunosThreads", threadId), updates);
}

function buildHistoryForApi(messages) {
  var trimmed = messages.slice(-20);
  var apiMessages = [{ role: "system", content: VUNOS_SYSTEM_PROMPT }];
  trimmed.forEach(function (m) {
    if (m.images && m.images.length) {
      var content = [{ type: "text", text: m.text || "" }];
      m.images.forEach(function (img) {
        content.push({ type: "image_url", image_url: { url: img } });
      });
      apiMessages.push({ role: m.role, content: content });
    } else {
      apiMessages.push({ role: m.role, content: m.text });
    }
  });
  return apiMessages;
}

function extractReplyText(data) {
  if (!data) return "";
  if (typeof data === "string") return data;
  if (data.reply) return data.reply;
  if (data.response) return data.response;
  if (data.message && typeof data.message === "string") return data.message;
  if (data.content && typeof data.content === "string") return data.content;
  if (data.choices && data.choices[0]) {
    var choice = data.choices[0];
    if (choice.message && choice.message.content) return choice.message.content;
    if (choice.text) return choice.text;
  }
  return "";
}

export async function sendToVunos(uid, threadId, userText, history, thinkMode) {
  var imagesToSend = pendingImages.slice();
  await saveMessage(uid, threadId, "user", userText, imagesToSend);
  clearPendingImages();

  var isFirstMessage = history.length === 0;
  await touchThread(uid, threadId, isFirstMessage ? deriveTitle(userText) : null, imagesToSend.length > 0);

  var apiMessages = buildHistoryForApi(
    history.concat([{ role: "user", text: userText, images: imagesToSend }])
  );

  var res = await fetch(VUNOS_WORKER_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages: apiMessages, think: !!thinkMode })
  });

  if (!res.ok) {
    var errText = "Vunos lagi gangguan (status " + res.status + "). Coba lagi bentar.";
    await saveMessage(uid, threadId, "assistant", errText, null);
    throw new Error(errText);
  }

  var data = await res.json();
  var replyText = extractReplyText(data) || "Vunos gak ngirim balasan apa-apa. Coba ulang ya.";
  await saveMessage(uid, threadId, "assistant", replyText, null);
  return replyText;
}

function formatCurrency(amount, code) {
  try {
    return new Intl.NumberFormat("id-ID", { maximumFractionDigits: 2 }).format(amount) + " " + code;
  } catch (e) {
    return amount + " " + code;
  }
}

function renderCurrencyWidget(jsonText) {
  var data;
  try { data = JSON.parse(jsonText); }
  catch (e) { return '<div class="rc-widget rc-error">Format currency dari Vunos gak valid.</div>'; }
  return (
    '<div class="rc-widget rc-currency">' +
      '<div class="rc-currency-row">' +
        '<span class="rc-currency-amount">' + formatCurrency(data.amount, data.from) + "</span>" +
        '<span class="rc-currency-arrow">&#8594;</span>' +
        '<span class="rc-currency-result">' + formatCurrency(data.result, data.to) + "</span>" +
      "</div>" +
      '<div class="rc-currency-rate">Kurs 1 ' + data.from + " = " + data.rate + " " + data.to + "</div>" +
    "</div>"
  );
}

function renderTableWidget(raw) {
  var rows = parseMarkdownTable(raw);
  if (!rows.length) return '<div class="rc-widget rc-error">Tabel kosong.</div>';
  var head = rows[0];
  var body = rows.slice(1);
  var html = '<div class="rc-widget rc-table-wrap"><table class="rc-table"><thead><tr>';
  head.forEach(function (h) { html += "<th>" + h + "</th>"; });
  html += "</tr></thead><tbody>";
  body.forEach(function (row) {
    html += "<tr>";
    row.forEach(function (cell) { html += "<td>" + cell + "</td>"; });
    html += "</tr>";
  });
  html += "</tbody></table></div>";
  return html;
}

function renderMathWidget(latex) {
  var id = "math-" + Math.random().toString(36).slice(2);
  setTimeout(function () {
    var node = document.getElementById(id);
    if (node && window.katex) {
      try { window.katex.render(latex, node, { throwOnError: false, displayMode: true }); }
      catch (e) { node.textContent = latex; }
    } else if (node) {
      node.textContent = latex;
    }
  }, 0);
  return '<div class="rc-widget rc-math" id="' + id + '"></div>';
}

function renderCodeWidget(code) {
  return '<pre class="rc-widget rc-code"><code>' + code
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</code></pre>";
}

export function renderVunosMessageHtml(text) {
  var segments = parseRichContent(text);
  return segments.map(function (seg) {
    if (seg.type === "table") return renderTableWidget(seg.content);
    if (seg.type === "math") return renderMathWidget(seg.content);
    if (seg.type === "currency") return renderCurrencyWidget(seg.content);
    if (seg.type === "code") return renderCodeWidget(seg.content);
    return renderTextBlock(seg.content);
  }).join("");
}
