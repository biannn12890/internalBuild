import { db } from "./firebase-config.js";
import {
  watchAuthState,
  loginWithGoogle,
  registerWithEmail,
  loginWithEmail,
  logout,
  mapAuthError
} from "./auth.js";
import {
  doc,
  getDoc,
  collection,
  getDocs
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";
import {
  openOrCreateChat,
  watchChatList,
  watchMessages,
  stopWatchingMessages,
  sendMessage,
  formatTimestamp
} from "./chat.js";
import {
  createThread,
  watchThreadList,
  stopWatchingThreadList,
  watchThreadMessages,
  stopWatchingThreadMessages,
  deleteThread,
  sendToVunos,
  renderVunosMessageHtml,
  addPendingImage,
  removePendingImage,
  clearPendingImages,
  getPendingImages
} from "./vunos.js";
import { compressImageToBase64, lazyMountAllWithin } from "./media.js";

var themePref = localStorage.getItem("corsur-theme") || "system";
function applyTheme() {
  if (themePref === "system") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.setAttribute("data-theme", themePref);
}
applyTheme();

var vunosFontSize = localStorage.getItem("vunos-font-size") || "md";
var vunosVoiceLang = localStorage.getItem("vunos-voice-lang") || "id-ID";

var myProfile = null;
var isRegisterMode = false;
var allChats = [];
var allContacts = [];
var allThreads = [];
var currentChatId = null;
var currentThreadId = null;
var currentOtherProfile = null;
var currentRoom = null;
var vunosMessagesCache = [];
var vunosIsThinking = false;
var vunosAutoResumed = false;
var thinkModeOn = false;
var pendingHumanImage = null;
var recognition = null;
var isRecording = false;
var recordCancelled = false;
var recordStartY = 0;

var el = {};
[
  "authScreen", "authSubtitle", "googleBtn", "authForm", "nameField", "emailField",
  "passwordField", "authError", "authSubmitBtn", "authToggleText", "authToggleBtn",
  "appShell", "meAvatarBtn", "newChatBtn", "corsurSettingsBtn", "logoutBtn",
  "chatSearchField", "chatListEl",
  "roomPane", "roomEmpty", "humanRoom", "vunosRoom", "backBtn", "vunosBackBtn",
  "roomAvatar", "roomName", "roomStatus", "messagesEl", "humanComposer", "humanAttachBtn",
  "humanAttachInput", "humanMessageField", "humanImagePreview",
  "vunosMenuBtn", "vunosThreadTitle", "vunosVisionBadge", "vunosNewChatBtn",
  "vunosMessagesEl", "vunosComposer", "vunosMessageField", "vunosThinkBtn",
  "vunosAttachBtn", "vunosMicBtn", "vunosImagePreview", "vunosAttachPopup",
  "vunosCameraOptBtn", "vunosPhotoOptBtn", "vunosDocOptBtn",
  "vunosAttachInput", "vunosCameraInput", "vunosDocInput",
  "vunosVoiceOverlay", "voiceWaveform", "voiceHint",
  "vunosSidebarOverlay", "vunosSidebar", "vunosSidebarNewBtn", "closeVunosSidebarBtn",
  "vunosThreadSearchField", "vunosThreadListEl", "vunosSettingsBtn",
  "vunosSidebarAvatar", "vunosSidebarName",
  "corsurSettingsModal", "closeCorsurSettingsBtn", "corsurSettingsAvatar",
  "corsurSettingsName", "corsurSettingsEmail", "corsurThemeSelect", "corsurLogoutBtn",
  "vunosSettingsModal", "closeVunosSettingsBtn", "vunosFontSizeSelect", "vunosVoiceLangSelect",
  "newChatModal", "closeNewChatBtn", "contactSearchField",
  "contactListEl", "lightbox", "lightboxImg"
].forEach(function (id) { el[id] = document.getElementById(id); });

el.vunosMessagesEl.setAttribute("data-font-size", vunosFontSize);

function avatarHtml(profile) {
  if (profile && profile.photoURL) {
    return '<img src="' + profile.photoURL + '" alt="">';
  }
  var color = (profile && profile.avatarColor) || "#5B6FFF";
  var initials = (profile && profile.avatarInitials) || "?";
  return '<span style="background:' + color + ';width:100%;height:100%;display:flex;align-items:center;justify-content:center;border-radius:50%;">' + initials + "</span>";
}

function setAvatar(container, profile) {
  container.innerHTML = avatarHtml(profile);
}

function escapeHtml(text) {
  var d = document.createElement("div");
  d.textContent = text;
  return d.innerHTML;
}

function showAuthScreen() {
  el.authScreen.classList.remove("hidden");
  el.appShell.classList.add("hidden");
}

function showAppShell() {
  el.authScreen.classList.add("hidden");
  el.appShell.classList.remove("hidden");
}

el.authToggleBtn.addEventListener("click", function () {
  isRegisterMode = !isRegisterMode;
  el.nameField.style.display = isRegisterMode ? "block" : "none";
  el.authSubmitBtn.textContent = isRegisterMode ? "Daftar" : "Masuk";
  el.authToggleText.textContent = isRegisterMode ? "Udah punya akun?" : "Belum punya akun?";
  el.authToggleBtn.textContent = isRegisterMode ? "Masuk" : "Daftar";
  el.authError.textContent = "";
});

el.googleBtn.addEventListener("click", async function () {
  el.authError.textContent = "";
  try {
    await loginWithGoogle();
  } catch (err) {
    el.authError.textContent = mapAuthError(err.code);
  }
});

el.authForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  el.authError.textContent = "";
  el.authSubmitBtn.disabled = true;
  try {
    if (isRegisterMode) {
      var name = el.nameField.value.trim();
      if (!name) {
        el.authError.textContent = "Nama wajib diisi.";
        el.authSubmitBtn.disabled = false;
        return;
      }
      await registerWithEmail(name, el.emailField.value.trim(), el.passwordField.value);
    } else {
      await loginWithEmail(el.emailField.value.trim(), el.passwordField.value);
    }
  } catch (err) {
    el.authError.textContent = mapAuthError(err.code);
  }
  el.authSubmitBtn.disabled = false;
});

async function doLogout() {
  stopWatchingMessages();
  stopWatchingThreadMessages();
  stopWatchingThreadList();
  await logout();
}
el.logoutBtn.addEventListener("click", doLogout);

async function initAppForUser(user) {
  var snap = await getDoc(doc(db, "users", user.uid));
  var data = snap.data();
  myProfile = {
    uid: user.uid,
    name: data.name,
    email: data.email,
    avatarColor: data.avatarColor,
    avatarInitials: data.avatarInitials,
    photoURL: data.photoURL
  };
  setAvatar(el.meAvatarBtn, myProfile);
  setAvatar(el.vunosSidebarAvatar, myProfile);
  el.vunosSidebarName.textContent = myProfile.name;
  showAppShell();
  watchChatList(myProfile.uid, onChatListUpdate);
  loadContactDirectory();
}

watchAuthState(initAppForUser, function () {
  myProfile = null;
  allChats = [];
  allThreads = [];
  currentThreadId = null;
  vunosAutoResumed = false;
  showAuthScreen();
});

function vunosPinnedRowHtml() {
  return (
    '<div class="chat-item" id="vunosPinnedRow">' +
      '<span class="avatar avatar-sm avatar-vunos"><img src="img/vunos-icon.png" alt="Vunos"></span>' +
      '<div class="chat-item-body">' +
        '<div class="chat-item-top"><span class="chat-item-name">Vunos</span></div>' +
        '<div class="chat-item-preview">Asisten AI kamu</div>' +
      "</div>" +
    "</div>"
  );
}

function renderChatList(filterText) {
  var html = vunosPinnedRowHtml();
  var query = (filterText || "").toLowerCase();

  var visible = allChats.filter(function (chat) {
    var other = otherParticipantInfo(chat);
    if (!other) return false;
    if (!query) return true;
    return other.name.toLowerCase().indexOf(query) !== -1;
  });

  if (visible.length === 0 && !query) {
    html += '<div class="chat-list-empty">Belum ada obrolan.<br>Ketuk + buat mulai chat baru.</div>';
  }

  visible.forEach(function (chat) {
    var other = otherParticipantInfo(chat);
    var isSelected = currentRoom === "human" && currentChatId === chat.id;
    html +=
      '<div class="chat-item' + (isSelected ? " selected" : "") + '" data-chat-id="' + chat.id + '">' +
        '<span class="avatar avatar-sm">' + avatarHtml(other) + "</span>" +
        '<div class="chat-item-body">' +
          '<div class="chat-item-top">' +
            '<span class="chat-item-name">' + escapeHtml(other.name) + "</span>" +
            '<span class="chat-item-time">' + formatTimestamp(chat.lastMessageTime) + "</span>" +
          "</div>" +
          '<div class="chat-item-preview">' + escapeHtml(chat.lastMessage || "") + "</div>" +
        "</div>" +
      "</div>";
  });

  el.chatListEl.innerHTML = html;

  var vunosRow = document.getElementById("vunosPinnedRow");
  if (vunosRow) vunosRow.addEventListener("click", openVunosRoom);

  el.chatListEl.querySelectorAll(".chat-item[data-chat-id]").forEach(function (row) {
    row.addEventListener("click", function () {
      var chatId = row.getAttribute("data-chat-id");
      var chat = allChats.filter(function (c) { return c.id === chatId; })[0];
      if (chat) openHumanRoom(chat);
    });
  });
}

function otherParticipantInfo(chat) {
  if (!chat.participantsInfo || !chat.participants) return null;
  var otherUid = chat.participants.filter(function (p) { return p !== myProfile.uid; })[0];
  return chat.participantsInfo[otherUid] ? Object.assign({ uid: otherUid }, chat.participantsInfo[otherUid]) : null;
}

function onChatListUpdate(chats) {
  allChats = chats;
  renderChatList(el.chatSearchField.value);
}

el.chatSearchField.addEventListener("input", function () {
  renderChatList(el.chatSearchField.value);
});

async function loadContactDirectory() {
  var snap = await getDocs(collection(db, "users"));
  allContacts = [];
  snap.forEach(function (docSnap) {
    var data = docSnap.data();
    if (data.uid !== myProfile.uid) allContacts.push(data);
  });
}

function renderContactList(filterText) {
  var query = (filterText || "").toLowerCase();
  var visible = allContacts.filter(function (c) {
    return !query || c.nameLower.indexOf(query) !== -1;
  });
  if (visible.length === 0) {
    el.contactListEl.innerHTML = '<div class="chat-list-empty">Gak ada user yang cocok.</div>';
    return;
  }
  el.contactListEl.innerHTML = visible.map(function (c) {
    return (
      '<div class="contact-item" data-uid="' + c.uid + '">' +
        '<span class="avatar avatar-sm">' + avatarHtml(c) + "</span>" +
        "<div>" +
          '<div class="contact-item-name">' + escapeHtml(c.name) + "</div>" +
          '<div class="contact-item-email">' + escapeHtml(c.email) + "</div>" +
        "</div>" +
      "</div>"
    );
  }).join("");

  el.contactListEl.querySelectorAll(".contact-item").forEach(function (row) {
    row.addEventListener("click", async function () {
      var uid = row.getAttribute("data-uid");
      var contact = allContacts.filter(function (c) { return c.uid === uid; })[0];
      el.newChatModal.classList.add("hidden");
      var chatId = await openOrCreateChat(myProfile, contact);
      var chat = { id: chatId, participants: [myProfile.uid, contact.uid], participantsInfo: buildParticipantsInfoLocal(contact) };
      openHumanRoom(chat);
    });
  });
}

function buildParticipantsInfoLocal(contact) {
  var info = {};
  info[myProfile.uid] = myProfile;
  info[contact.uid] = contact;
  return info;
}

el.newChatBtn.addEventListener("click", function () {
  el.newChatModal.classList.remove("hidden");
  el.contactSearchField.value = "";
  renderContactList("");
});
el.closeNewChatBtn.addEventListener("click", function () {
  el.newChatModal.classList.add("hidden");
});
el.newChatModal.addEventListener("click", function (e) {
  if (e.target === el.newChatModal) el.newChatModal.classList.add("hidden");
});
el.contactSearchField.addEventListener("input", function () {
  renderContactList(el.contactSearchField.value);
});

async function openHumanRoom(chat) {
  currentRoom = "human";
  currentChatId = chat.id;
  currentOtherProfile = otherParticipantInfo(chat) || otherParticipantInfoFromMap(chat);

  el.roomEmpty.classList.add("hidden");
  el.vunosRoom.classList.add("hidden");
  el.humanRoom.classList.remove("hidden");
  el.roomPane.classList.add("active");

  setAvatar(el.roomAvatar, currentOtherProfile);
  el.roomName.textContent = currentOtherProfile.name;
  el.roomStatus.textContent = "";

  getDoc(doc(db, "users", currentOtherProfile.uid)).then(function (snap) {
    var d = snap.data();
    if (!d) return;
    el.roomStatus.textContent = d.status === "online" ? "Online" : "Offline";
  });

  stopWatchingMessages();
  watchMessages(chat.id, renderHumanMessages);
  renderChatList(el.chatSearchField.value);
}

function otherParticipantInfoFromMap(chat) {
  var otherUid = chat.participants.filter(function (p) { return p !== myProfile.uid; })[0];
  return Object.assign({ uid: otherUid }, chat.participantsInfo[otherUid]);
}

function bubbleImageHtml(base64) {
  return '<img class="msg-image media-loading-placeholder" data-src="' + base64 + '" alt="Gambar" loading="lazy">';
}

function renderHumanMessages(messages) {
  var html = messages.map(function (m) {
    var mine = m.senderId === myProfile.uid;
    var inner = "";
    if (m.image) inner += bubbleImageHtml(m.image);
    if (m.text) inner += escapeHtml(m.text);
    return (
      '<div class="bubble-row' + (mine ? " mine" : "") + '">' +
        '<div class="bubble ' + (mine ? "mine" : "theirs") + '">' +
          inner +
          '<span class="bubble-time">' + formatTimestamp(m.createdAt) + "</span>" +
        "</div>" +
      "</div>"
    );
  }).join("");
  el.messagesEl.innerHTML = html;
  lazyMountAllWithin(el.messagesEl);
  el.messagesEl.scrollTop = el.messagesEl.scrollHeight;
}

el.humanComposer.addEventListener("submit", async function (e) {
  e.preventDefault();
  var text = el.humanMessageField.value;
  var image = pendingHumanImage;
  if (!text.trim() && !image) return;
  el.humanMessageField.value = "";
  clearHumanImagePreview();
  await sendMessage(currentChatId, myProfile.uid, text, image);
});

el.humanAttachBtn.addEventListener("click", function () { el.humanAttachInput.click(); });
el.humanAttachInput.addEventListener("change", async function () {
  var file = el.humanAttachInput.files[0];
  if (!file) return;
  try {
    var base64 = await compressImageToBase64(file);
    pendingHumanImage = base64;
    el.humanImagePreview.innerHTML = '<img src="' + base64 + '" alt=""><button type="button" class="image-preview-remove" id="removeHumanImage">&times;</button>';
    el.humanImagePreview.classList.remove("hidden");
    document.getElementById("removeHumanImage").addEventListener("click", clearHumanImagePreview);
  } catch (err) {
    console.error(err);
  }
  el.humanAttachInput.value = "";
});

function clearHumanImagePreview() {
  pendingHumanImage = null;
  el.humanImagePreview.classList.add("hidden");
  el.humanImagePreview.innerHTML = "";
}

el.backBtn.addEventListener("click", function () { el.roomPane.classList.remove("active"); });
el.vunosBackBtn.addEventListener("click", function () { el.roomPane.classList.remove("active"); });

function multiImagesHtml(images) {
  return images.map(function (b64) { return bubbleImageHtml(b64); }).join("");
}

function vunosUserTurnHtml(m) {
  var inner = "";
  if (m.images && m.images.length) inner += multiImagesHtml(m.images);
  if (m.text) inner += escapeHtml(m.text);
  return '<div class="vunos-turn user"><div class="bubble">' + inner + "</div></div>";
}

function vunosAssistantTurnHtml(m) {
  return (
    '<div class="vunos-turn assistant">' +
      '<div class="vunos-reply">' +
        '<span class="vunos-reply-avatar"><img src="img/vunos-icon.png" alt=""></span>' +
        '<div class="vunos-reply-body">' + renderVunosMessageHtml(m.text) + "</div>" +
      "</div>" +
    "</div>"
  );
}

function thinkingTurnHtml() {
  return (
    '<div class="vunos-turn assistant">' +
      '<div class="vunos-reply">' +
        '<span class="vunos-reply-avatar"><img src="img/vunos-icon.png" alt=""></span>' +
        '<div class="vunos-thinking"><span></span><span></span><span></span></div>' +
      "</div>" +
    "</div>"
  );
}

function renderVunosTurns(messages) {
  vunosMessagesCache = messages;
  var html = messages.map(function (m) {
    return m.role === "user" ? vunosUserTurnHtml(m) : vunosAssistantTurnHtml(m);
  }).join("");
  if (vunosIsThinking) html += thinkingTurnHtml();
  if (!html) {
    html = '<div class="chat-list-empty">Mulai ngobrol sama Vunos.</div>';
  }
  el.vunosMessagesEl.innerHTML = html;
  lazyMountAllWithin(el.vunosMessagesEl);
  el.vunosMessagesEl.scrollTop = el.vunosMessagesEl.scrollHeight;
}

function applyThreadHeader(thread) {
  el.vunosThreadTitle.textContent = (thread && thread.title) || "Percakapan baru";
  el.vunosVisionBadge.classList.toggle("hidden", !(thread && thread.hasVision));
}

function switchToThread(threadId) {
  currentThreadId = threadId;
  var thread = allThreads.filter(function (t) { return t.id === threadId; })[0];
  applyThreadHeader(thread);
  stopWatchingThreadMessages();
  watchThreadMessages(myProfile.uid, threadId, renderVunosTurns);
  renderThreadList(el.vunosThreadSearchField.value);
}

function startNewThread() {
  currentThreadId = null;
  stopWatchingThreadMessages();
  vunosMessagesCache = [];
  renderVunosTurns([]);
  applyThreadHeader(null);
  el.vunosMessageField.value = "";
  clearVunosThumbs();
  closeAttachPopup();
  closeVunosSidebar();
  el.vunosMessageField.focus();
}
el.vunosNewChatBtn.addEventListener("click", startNewThread);
el.vunosSidebarNewBtn.addEventListener("click", startNewThread);

function startOfDay(d) { var x = new Date(d); x.setHours(0, 0, 0, 0); return x; }

function groupThreadsByDate(threads) {
  var today = startOfDay(new Date());
  var yesterday = new Date(today); yesterday.setDate(yesterday.getDate() - 1);
  var monthAgo = new Date(today); monthAgo.setDate(monthAgo.getDate() - 30);

  var groups = [
    { label: "Hari ini", items: [] },
    { label: "Kemarin", items: [] },
    { label: "30 hari terakhir", items: [] },
    { label: "Lebih lama", items: [] }
  ];

  threads.forEach(function (t) {
    var ts = t.updatedAt && t.updatedAt.toDate ? t.updatedAt.toDate() : new Date();
    if (ts >= today) groups[0].items.push(t);
    else if (ts >= yesterday) groups[1].items.push(t);
    else if (ts >= monthAgo) groups[2].items.push(t);
    else groups[3].items.push(t);
  });

  return groups.filter(function (g) { return g.items.length > 0; });
}

function renderThreadList(filterText) {
  var query = (filterText || "").toLowerCase();
  var filtered = allThreads.filter(function (t) {
    return !query || (t.title || "").toLowerCase().indexOf(query) !== -1;
  });
  if (!filtered.length) {
    el.vunosThreadListEl.innerHTML = '<div class="thread-list-empty">Belum ada percakapan.</div>';
    return;
  }
  var groups = groupThreadsByDate(filtered);
  var html = groups.map(function (g) {
    var items = g.items.map(function (t) {
      var active = t.id === currentThreadId;
      return (
        '<div class="thread-item' + (active ? " active" : "") + '" data-thread-id="' + t.id + '">' +
          '<span class="thread-item-title">' + escapeHtml(t.title || "Percakapan baru") + "</span>" +
          '<button class="thread-item-delete" type="button" data-delete-id="' + t.id + '" aria-label="Hapus">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>' +
          "</button>" +
        "</div>"
      );
    }).join("");
    return '<div class="thread-group-label">' + g.label + "</div>" + items;
  }).join("");
  el.vunosThreadListEl.innerHTML = html;

  el.vunosThreadListEl.querySelectorAll(".thread-item").forEach(function (row) {
    row.addEventListener("click", function (e) {
      if (e.target.closest(".thread-item-delete")) return;
      switchToThread(row.getAttribute("data-thread-id"));
      closeVunosSidebar();
    });
  });
  el.vunosThreadListEl.querySelectorAll(".thread-item-delete").forEach(function (btn) {
    btn.addEventListener("click", async function (e) {
      e.stopPropagation();
      var id = btn.getAttribute("data-delete-id");
      await deleteThread(myProfile.uid, id);
      if (id === currentThreadId) startNewThread();
    });
  });
}

function onThreadListUpdate(threads) {
  allThreads = threads;
  renderThreadList(el.vunosThreadSearchField.value);
  if (currentThreadId) {
    var t = allThreads.filter(function (x) { return x.id === currentThreadId; })[0];
    if (t) applyThreadHeader(t);
  } else if (allThreads.length && !vunosAutoResumed) {
    vunosAutoResumed = true;
    switchToThread(allThreads[0].id);
  }
}

function openVunosRoom() {
  currentRoom = "vunos";
  currentChatId = null;
  el.newChatModal.classList.add("hidden");

  el.roomEmpty.classList.add("hidden");
  el.humanRoom.classList.add("hidden");
  el.vunosRoom.classList.remove("hidden");
  el.roomPane.classList.add("active");

  stopWatchingMessages();
  watchThreadList(myProfile.uid, onThreadListUpdate);
  renderChatList(el.chatSearchField.value);
}

function openVunosSidebar() {
  el.vunosSidebarOverlay.classList.remove("hidden");
  renderThreadList(el.vunosThreadSearchField.value);
}
function closeVunosSidebar() { el.vunosSidebarOverlay.classList.add("hidden"); }
el.vunosMenuBtn.addEventListener("click", openVunosSidebar);
el.closeVunosSidebarBtn.addEventListener("click", closeVunosSidebar);
el.vunosSidebarOverlay.addEventListener("click", function (e) {
  if (e.target === el.vunosSidebarOverlay) closeVunosSidebar();
});
el.vunosThreadSearchField.addEventListener("input", function () {
  renderThreadList(el.vunosThreadSearchField.value);
});

el.vunosThinkBtn.addEventListener("click", function () {
  thinkModeOn = !thinkModeOn;
  el.vunosThinkBtn.classList.toggle("active", thinkModeOn);
  el.vunosThinkBtn.setAttribute("aria-pressed", String(thinkModeOn));
});

el.vunosComposer.addEventListener("submit", async function (e) {
  e.preventDefault();
  var text = el.vunosMessageField.value.trim();
  if (!text && !getPendingImages().length) return;
  el.vunosMessageField.value = "";
  closeAttachPopup();

  if (!currentThreadId) {
    currentThreadId = await createThread(myProfile.uid);
    watchThreadMessages(myProfile.uid, currentThreadId, renderVunosTurns);
  }

  vunosIsThinking = true;
  renderVunosTurns(vunosMessagesCache);

  try {
    await sendToVunos(myProfile.uid, currentThreadId, text, vunosMessagesCache, thinkModeOn);
  } catch (err) {
    console.error(err);
  }
  vunosIsThinking = false;
  clearVunosThumbs();
});

function toggleAttachPopup() {
  el.vunosAttachPopup.classList.toggle("hidden");
}
function closeAttachPopup() {
  el.vunosAttachPopup.classList.add("hidden");
}
el.vunosAttachBtn.addEventListener("click", toggleAttachPopup);
el.vunosCameraOptBtn.addEventListener("click", function () { el.vunosCameraInput.click(); });
el.vunosPhotoOptBtn.addEventListener("click", function () { el.vunosAttachInput.click(); });
el.vunosDocOptBtn.addEventListener("click", function () { el.vunosDocInput.click(); });

function renderVunosThumbs() {
  var images = getPendingImages();
  if (!images.length) {
    el.vunosImagePreview.classList.add("hidden");
    el.vunosImagePreview.innerHTML = "";
    return;
  }
  el.vunosImagePreview.classList.remove("hidden");
  el.vunosImagePreview.innerHTML = images.map(function (b64, i) {
    return (
      '<div class="attach-thumb">' +
        '<img src="' + b64 + '" alt="">' +
        '<button type="button" class="attach-thumb-remove" data-remove-index="' + i + '">&times;</button>' +
      "</div>"
    );
  }).join("");
  el.vunosImagePreview.querySelectorAll("[data-remove-index]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      removePendingImage(parseInt(btn.getAttribute("data-remove-index"), 10));
      renderVunosThumbs();
    });
  });
}

function clearVunosThumbs() {
  clearPendingImages();
  renderVunosThumbs();
}

async function handleVunosImageFile(file) {
  if (!file) return;
  try {
    var base64 = await compressImageToBase64(file);
    addPendingImage(base64);
    renderVunosThumbs();
  } catch (err) {
    console.error(err);
  }
}
el.vunosAttachInput.addEventListener("change", function () {
  handleVunosImageFile(el.vunosAttachInput.files[0]);
  el.vunosAttachInput.value = "";
  closeAttachPopup();
});
el.vunosCameraInput.addEventListener("change", function () {
  handleVunosImageFile(el.vunosCameraInput.files[0]);
  el.vunosCameraInput.value = "";
  closeAttachPopup();
});

var TEXT_DOC_EXTENSIONS = ["txt", "md", "csv", "json", "js", "ts", "py", "html", "css", "yml", "yaml", "xml", "log"];
function showDocNotice(msg) {
  var notice = document.createElement("div");
  notice.className = "doc-notice";
  notice.textContent = msg;
  el.vunosAttachPopup.appendChild(notice);
  el.vunosAttachPopup.classList.remove("hidden");
  setTimeout(function () { notice.remove(); }, 3200);
}
el.vunosDocInput.addEventListener("change", function () {
  var file = el.vunosDocInput.files[0];
  el.vunosDocInput.value = "";
  closeAttachPopup();
  if (!file) return;
  var ext = file.name.split(".").pop().toLowerCase();
  if (TEXT_DOC_EXTENSIONS.indexOf(ext) === -1 || file.size > 100000) {
    showDocNotice("Tipe atau ukuran file ini belum didukung. Coba file teks kecil (.txt/.md/.csv/.json).");
    return;
  }
  var reader = new FileReader();
  reader.onload = function () {
    var content = String(reader.result || "").slice(0, 6000);
    var insertion = "```" + ext + "\n" + content + "\n```\n\n";
    el.vunosMessageField.value = insertion + el.vunosMessageField.value;
    el.vunosMessageField.focus();
  };
  reader.onerror = function () { showDocNotice("Gagal baca file."); };
  reader.readAsText(file);
});

function supportsSpeechRecognition() {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

function buildWaveformBars() {
  var bars = "";
  for (var i = 0; i < 28; i++) {
    bars += '<span style="animation-delay:' + (i * 0.03) + 's"></span>';
  }
  return bars;
}

function startRecording(clientY) {
  if (!supportsSpeechRecognition()) {
    var original = el.vunosMessageField.placeholder;
    el.vunosMessageField.placeholder = "Browser ini gak support rekam suara";
    setTimeout(function () { el.vunosMessageField.placeholder = original; }, 2200);
    return;
  }
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SR();
  recognition.lang = vunosVoiceLang;
  recognition.interimResults = true;
  recognition.continuous = true;
  recordCancelled = false;
  recordStartY = clientY;
  isRecording = true;

  var finalTranscript = "";
  recognition.onresult = function (event) {
    var interim = "";
    for (var i = event.resultIndex; i < event.results.length; i++) {
      if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
      else interim += event.results[i][0].transcript;
    }
    recognition._lastTranscript = (finalTranscript + " " + interim).trim();
  };
  recognition.onerror = function () {};

  el.vunosComposer.classList.add("hidden");
  el.vunosVoiceOverlay.classList.remove("hidden");
  el.voiceWaveform.innerHTML = buildWaveformBars();
  el.voiceHint.textContent = "Lepas buat kirim, geser ke atas buat batal";

  try { recognition.start(); } catch (err) { console.error(err); }
}

function endRecording(shouldSend) {
  isRecording = false;
  el.vunosVoiceOverlay.classList.add("hidden");
  el.vunosVoiceOverlay.classList.remove("cancel-zone");
  el.vunosComposer.classList.remove("hidden");

  if (!recognition) return;
  var transcript = (recognition._lastTranscript || "").trim();
  try { recognition.stop(); } catch (err) { /* abaikan */ }
  recognition = null;

  if (shouldSend && transcript) {
    el.vunosMessageField.value = transcript;
    if (el.vunosComposer.requestSubmit) el.vunosComposer.requestSubmit();
    else el.vunosComposer.dispatchEvent(new Event("submit", { cancelable: true }));
  }
}

function finishMicPointer() {
  if (!isRecording) return;
  el.vunosMicBtn.classList.remove("recording");
  endRecording(!recordCancelled);
}

el.vunosMicBtn.addEventListener("pointerdown", function (e) {
  e.preventDefault();
  try { el.vunosMicBtn.setPointerCapture(e.pointerId); } catch (err) { /* abaikan */ }
  startRecording(e.clientY);
  el.vunosMicBtn.classList.add("recording");
});
el.vunosMicBtn.addEventListener("pointermove", function (e) {
  if (!isRecording) return;
  var delta = recordStartY - e.clientY;
  if (delta > 60) {
    recordCancelled = true;
    el.vunosVoiceOverlay.classList.add("cancel-zone");
    el.voiceHint.textContent = "Lepas buat batal";
  } else {
    recordCancelled = false;
    el.vunosVoiceOverlay.classList.remove("cancel-zone");
    el.voiceHint.textContent = "Lepas buat kirim, geser ke atas buat batal";
  }
});
el.vunosMicBtn.addEventListener("pointerup", finishMicPointer);
el.vunosMicBtn.addEventListener("pointercancel", function () { recordCancelled = true; finishMicPointer(); });

function openCorsurSettings() {
  setAvatar(el.corsurSettingsAvatar, myProfile);
  el.corsurSettingsName.textContent = myProfile.name;
  el.corsurSettingsEmail.textContent = myProfile.email;
  el.corsurThemeSelect.value = themePref;
  el.corsurSettingsModal.classList.remove("hidden");
}
el.corsurSettingsBtn.addEventListener("click", openCorsurSettings);
el.closeCorsurSettingsBtn.addEventListener("click", function () {
  el.corsurSettingsModal.classList.add("hidden");
});
el.corsurSettingsModal.addEventListener("click", function (e) {
  if (e.target === el.corsurSettingsModal) el.corsurSettingsModal.classList.add("hidden");
});
el.corsurThemeSelect.addEventListener("change", function () {
  themePref = el.corsurThemeSelect.value;
  localStorage.setItem("corsur-theme", themePref);
  applyTheme();
});
el.corsurLogoutBtn.addEventListener("click", async function () {
  el.corsurSettingsModal.classList.add("hidden");
  await doLogout();
});

function openVunosSettings() {
  el.vunosFontSizeSelect.value = vunosFontSize;
  el.vunosVoiceLangSelect.value = vunosVoiceLang;
  el.vunosSettingsModal.classList.remove("hidden");
}
el.vunosSettingsBtn.addEventListener("click", function () {
  closeVunosSidebar();
  openVunosSettings();
});
el.closeVunosSettingsBtn.addEventListener("click", function () {
  el.vunosSettingsModal.classList.add("hidden");
});
el.vunosSettingsModal.addEventListener("click", function (e) {
  if (e.target === el.vunosSettingsModal) el.vunosSettingsModal.classList.add("hidden");
});
el.vunosFontSizeSelect.addEventListener("change", function () {
  vunosFontSize = el.vunosFontSizeSelect.value;
  localStorage.setItem("vunos-font-size", vunosFontSize);
  el.vunosMessagesEl.setAttribute("data-font-size", vunosFontSize);
});
el.vunosVoiceLangSelect.addEventListener("change", function () {
  vunosVoiceLang = el.vunosVoiceLangSelect.value;
  localStorage.setItem("vunos-voice-lang", vunosVoiceLang);
});

document.addEventListener("click", function (e) {
  if (e.target.classList && e.target.classList.contains("msg-image")) {
    var src = e.target.getAttribute("src") || e.target.getAttribute("data-src");
    if (!src) return;
    el.lightboxImg.src = src;
    el.lightbox.classList.remove("hidden");
  }
});
el.lightbox.addEventListener("click", function () {
  el.lightbox.classList.add("hidden");
  el.lightboxImg.src = "";
});
