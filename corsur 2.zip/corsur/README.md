# Corsur

Chat app kaya WA, gratis, pake Firebase (Auth + Firestore) buat backend dan
Cloudflare Pages buat hosting. Vunos — asisten AI yang nempel kaya kontak
pinned — punya UI ala app AI pada umumnya (sidebar riwayat percakapan,
mode Think, lampiran kamera/foto/dokumen, rekam suara) dan responnya plain
text, tapi tabel/rumus matematika/konversi mata uang otomatis jadi widget
card.

## 1. Bikin project Firebase

1. Buka https://console.firebase.google.com, klik **Add project**, kasih nama bebas.
2. Analytics boleh di-skip, gak kepake di sini.
3. Setelah project jadi, di halaman Project Overview klik ikon **Web (`</>`)**
   buat register web app. Kasih nickname (misal "corsur-web"), **gak perlu**
   centang Firebase Hosting (kita pakai Cloudflare Pages).
4. Firebase bakal nunjukin object `firebaseConfig`. Copy semua isinya.
5. Buka `js/firebase-config.js` di project ini, ganti seluruh field
   `GANTI_DENGAN_...` dengan value asli dari config tadi.

## 2. Aktifin metode login

Di Firebase Console: **Build > Authentication > Sign-in method**.

- Aktifin **Google** — pilih email support buat project, save.
- Aktifin **Email/Password** — toggle on, save.

Nomor HP/SMS OTP **sengaja gak dipake** karena itu satu-satunya metode auth
Firebase yang berbayar (kena charge per SMS walau usernya cuma 2 orang).

### Authorized domains (wajib biar Google Sign-In jalan)

Masih di halaman Authentication > Settings > **Authorized domains**, tambahin:
- Domain Cloudflare Pages lu (misal `corsur.pages.dev`)
- Custom domain kalo ada
- `localhost` udah otomatis ada, buat testing lokal

## 3. Bikin Firestore Database

1. **Build > Firestore Database > Create database**.
2. Pilih lokasi server (misal `asia-southeast2` biar deket Indonesia).
3. Mode **production** (bukan test mode) — udah aman karena rules-nya
   disediain di file `firestore.rules`.
4. Buka tab **Rules** di Firestore Console, copy-paste seluruh isi file
   `firestore.rules` dari project ini, klik **Publish**.

Tanpa rules ini, semua read/write bakal ketolak ("Missing or insufficient
permissions") karena default Firestore nolak semua akses.

## 4. Hubungin ke worker Vunos

`js/firebase-config.js` udah ngarah ke `https://vunos.bian27374.workers.dev`.
Worker itu cuma nerima `POST` (gue cek, `GET`-nya balikin 405).

`js/vunos.js` ngirim body:
```json
{ "messages": [ { "role": "system|user|assistant", "content": "..." } ], "think": false }
```

Field `think` ngikutin status toggle **Think** di composer — itu cuma sinyal
yang dikirim ke worker, efek asli (misal ganti parameter reasoning di model)
tergantung implementasi di sisi worker lu.

Balasan diparsing dengan nyoba beberapa bentuk umum: `data.reply`,
`data.response`, `data.message`, `data.content`, atau format OpenAI-style
`data.choices[0].message.content`. Kalo worker lu pake nama field laen,
tinggal sesuaiin satu fungsi `extractReplyText()` di `js/vunos.js`.

### Soal widget tabel/math/currency

Vunos dikasih instruksi sistem (system prompt) buat bungkus konten khusus
pake fenced block: ` ```table `, ` ```math `, ` ```currency `. Parser di
`js/richcontent.js` bakal nangkep itu dan render jadi widget. Ada juga
fallback deteksi tabel markdown biasa (`| a | b |`) kalo model gak nurut
fenced block.

### Math rendering

Pake KaTeX dari CDN (cdnjs.cloudflare.com), udah otomatis ke-include di
`index.html`.

## 5. UI Vunos (ala app AI pada umumnya)

- **Sidebar riwayat** — tombol hamburger di header Vunos buka daftar
  percakapan, dikelompokin per "Hari ini / Kemarin / 30 hari terakhir /
  Lebih lama". Tiap percakapan adalah thread Firestore terpisah
  (`users/{uid}/vunosThreads/{threadId}`), bisa dihapus lewat tombol silang
  kecil di tiap baris.
- **Percakapan baru** — tombol "+" di header atau di sidebar. Thread baru
  cuma beneran dibuat di Firestore pas pesan pertama terkirim (biar gak ada
  thread kosong nyampah).
- **Badge Vision** — muncul otomatis di bawah judul kalo thread itu pernah
  ada gambar yang dikirim.
- **Think** — pill toggle di composer, ngirim flag `think:true/false` ke
  worker (lihat bagian 4).
- **Lampiran** — tombol "+" di composer buka popup Kamera / Foto / Dokumen.
  Kamera & Foto: ambil/pilih gambar, dikompres otomatis, bisa nambahin lebih
  dari satu sebelum kirim (preview muncul di atas composer). Dokumen: cuma
  dukung file teks kecil (.txt/.md/.csv/.json/dll, maks ~100KB) — isinya
  dibaca dan ditempel ke kotak pesan biar Vunos bisa baca; file lain bakal
  dapet notifikasi belum didukung (gak pura-pura jalan).
- **Rekam suara** — tahan tombol mic buat ngomong (pake Web Speech API
  bawaan browser), lepas buat kirim, geser ke atas buat batal. **Catatan:**
  Speech Recognition ini fitur browser, bukan punya Corsur — dukungannya
  beda-beda (Chrome/Android WebView biasanya oke, sebagian browser lain
  belum support). Kalo gak didukung, field pesan kasih tau sebentar.
- **Pengaturan Vunos** (lewat avatar di bagian bawah sidebar) — ukuran teks
  balasan dan bahasa buat rekam suara, disimpen di localStorage device.

## 6. Pengaturan Corsur vs Vunos — dipisah

- **Pengaturan Corsur** (ikon gerigi di header daftar chat) — profil akun,
  tema (Ikutin sistem / Terang / Gelap), tombol keluar.
- **Pengaturan Vunos** (lewat sidebar Vunos) — khusus hal yang berkaitan
  sama AI: ukuran teks balasan, bahasa rekam suara, info singkat soal Vunos.

Keduanya modal terpisah, gak nyampur, sesuai yang diminta.

## 7. Icon

`img/corsur-icon.png` dan `img/vunos-icon.png` udah dipotong alpha-mask
rounded-rect dari file asli yang lu kirim, di-resize ke 256px biar ringan.
Kalo mau ganti, timpa aja kedua file itu dengan nama yang sama.

## 8. Deploy ke Cloudflare Pages

1. Push folder ini ke repo GitHub (atau upload manual lewat dashboard
   Cloudflare Pages — "Direct Upload").
2. Di Cloudflare dashboard: **Workers & Pages > Create > Pages**.
3. Build command: kosongin (gak ada build step, vanilla HTML/CSS/JS).
4. Output directory: `/` (root folder ini).
5. Deploy. Domain `*.pages.dev` yang muncul itu yang harus didaftarin di
   Authorized domains Firebase (langkah 2).

## Struktur file

```
corsur/
  index.html
  firestore.rules
  css/
    style.css       - design system utama, bubble chat, auth screen, settings modal generic, theme override
    vunos.css       - layout Vunos: header center+badge, composer+Think, attach popup, voice overlay, sidebar drawer
  js/
    firebase-config.js
    auth.js         - login Google + email/password
    chat.js         - chat 1-on-1 antar user
    vunos.js        - multi-thread Vunos: CRUD thread, kirim ke worker, system prompt, render widget
    richcontent.js  - deteksi & parsing blok table/math/currency/code
    media.js        - kompresi gambar + lazy loading
    app.js          - controller utama: auth, navigasi, render UI, sidebar, settings, rekam suara
  img/
    corsur-icon.png
    vunos-icon.png
```

## Batasan yang perlu lu tau

- Gambar dikompres ke maksimal 1280px sisi terpanjang & disimpen sebagai
  base64 langsung di dokumen Firestore (limit 1 dokumen = 1MB). Cukup buat
  foto candid, tapi kalo butuh kirim gambar resolusi tinggi/banyak banget,
  baiknya pindah ke Cloud Storage for Firebase (langkah lanjutan, gak gue
  bikin di sini biar tetep sesuai batas "gratis & simpel").
- Lampiran Dokumen di Vunos cuma baca file teks kecil, bukan parsing PDF/DOCX
  beneran — itu butuh library tambahan yang berat buat app single-file ini.
- Rekam suara gak nyimpen file audio, cuma transkrip teks lewat Speech
  Recognition browser. Kalo browser/WebView gak support, fiturnya gak bisa
  dipaksa jalan (bukan masalah kode Corsur, tapi dukungan browser).
- Pencarian kontak masih client-side (load semua user terus difilter di
  browser). Buat skala personal/kecil ini gak masalah; kalo user udah
  ratusan baru perlu mikirin indexing/search service.
